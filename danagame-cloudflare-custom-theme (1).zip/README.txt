PANDUAN DEPLOY CLOUDFLARE PAGES

1. Buka Cloudflare Dashboard > Workers & Pages > Create application > Pages.
2. Pilih Direct Upload / Drag and drop files.
3. Upload file ZIP ini (tidak perlu mengunggah README secara terpisah).
4. Deploy site dan buka alamat <project>.pages.dev.

File utama: index.html
CSS: styles.css
Javascript: script.js
Gambar: assets/ (hero original buatan khusus, logo pengguna, dan ilustrasi SVG).

Catatan: Ini microsite artikel edukasi, BUKAN situs resmi DANA. Tautan ke sumber terkait membuka website eksternal. Data versi aplikasi di halaman ini merupakan rujukan bertanggal 28 Okt 2026. Periksa kembali jika data aplikasi berubah.

Jika ingin menambahkan canonical / og:image absolute URL, lakukan setelah URL pages.dev final diketahui.
